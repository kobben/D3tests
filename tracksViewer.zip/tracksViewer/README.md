Using the D3 API  to map GSP track data and stops detected in them from a geojson.
